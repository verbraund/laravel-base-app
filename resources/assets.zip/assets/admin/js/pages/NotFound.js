import React from 'react';

export default function NotFound(){

    return (
        <div>
            <h2>404! Hot Found</h2>
        </div>
    );
}
