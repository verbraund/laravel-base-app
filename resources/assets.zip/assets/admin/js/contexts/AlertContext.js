import React from "react";

export const AlertContext = React.createContext();
